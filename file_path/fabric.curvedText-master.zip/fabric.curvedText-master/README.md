### curvedText for fabric.js


Demo: http://jsfiddle.net/NHs8t/
