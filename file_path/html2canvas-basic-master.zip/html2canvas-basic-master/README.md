html2canvas-basic
=================

Basic usage for html2canvas library with Javascript and PHP.

html2canvas official page: http://html2canvas.hertzen.com/

This sample implements how to use html2canvas for capturing a div and save it to server with PHP code.

Documentation and live demo can be found here: http://www.kubilayerdogan.net/?p=304