<?php
$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

if($actual_link == "http://newdev.willowandhall.co.uk/"){ ?> <!--
	Start of DoubleClick Floodlight Tag: Please do not remove
	Activity name of this tag: 01. Homepage
	URL of the web page where the tag is expected to be placed: https://www.willowandhall.co.uk/
	This tag must be placed between the <body> and </body> tags, as close as possible to the opening tag.
	Creation Date: 06/02/2016
	-->
	<script type="text/javascript">
	var axel = Math.random() + "";
	var a = axel * 10000000000000;
	document.write('<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=01hom0;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>');
	</script>
	<noscript>
	<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=01hom0;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?" width="1" height="1" frameborder="0" style="display:none"></iframe>
	</noscript>
	<!-- End of DoubleClick Floodlight Tag: Please do not remove --> 
<?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/sofa-beds.html"){ ?> <!--
Start of DoubleClick Floodlight Tag: Please do not remove
Activity name of this tag: 02. Product - Sofa Beds
URL of the web page where the tag is expected to be placed: https://www.willowandhall.co.uk/sofa-beds.html
This tag must be placed between the <body> and </body> tags, as close as possible to the opening tag.
Creation Date: 06/02/2016
-->
<script type="text/javascript">
var axel = Math.random() + "";
var a = axel * 10000000000000;
document.write('<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=02pro0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>');
</script>
<noscript>
<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=02pro0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?" width="1" height="1" frameborder="0" style="display:none"></iframe>
</noscript>
<!-- End of DoubleClick Floodlight Tag: Please do not remove -->
<?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/sofas.html"){ ?> <!--
Start of DoubleClick Floodlight Tag: Please do not remove
Activity name of this tag: 03. Product - Sofas
URL of the web page where the tag is expected to be placed: https://www.willowandhall.co.uk/sofas.html
This tag must be placed between the <body> and </body> tags, as close as possible to the opening tag.
Creation Date: 06/02/2016
-->
<script type="text/javascript">
var axel = Math.random() + "";
var a = axel * 10000000000000;
document.write('<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=03pro0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>');
</script>
<noscript>
<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=03pro0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?" width="1" height="1" frameborder="0" style="display:none"></iframe>
</noscript>
<!-- End of DoubleClick Floodlight Tag: Please do not remove -->
<?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/armchairs.html"){ ?> <!--
Start of DoubleClick Floodlight Tag: Please do not remove
Activity name of this tag: 04. Product - Armchair
URL of the web page where the tag is expected to be placed: https://www.willowandhall.co.uk/armchairs.html
This tag must be placed between the <body> and </body> tags, as close as possible to the opening tag.
Creation Date: 06/02/2016
-->
<script type="text/javascript">
var axel = Math.random() + "";
var a = axel * 10000000000000;
document.write('<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=04pro0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>');
</script>
<noscript>
<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=04pro0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?" width="1" height="1" frameborder="0" style="display:none"></iframe>
</noscript>
<!-- End of DoubleClick Floodlight Tag: Please do not remove -->
<?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/beds-mattresses.html"){ ?> <!--
Start of DoubleClick Floodlight Tag: Please do not remove
Activity name of this tag: 05. Product - Mattress
URL of the web page where the tag is expected to be placed: https://www.willowandhall.co.uk/beds-mattresses.html
This tag must be placed between the <body> and </body> tags, as close as possible to the opening tag.
Creation Date: 06/02/2016
-->
<script type="text/javascript">
var axel = Math.random() + "";
var a = axel * 10000000000000;
document.write('<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=05pro0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>');
</script>
<noscript>
<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=05pro0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?" width="1" height="1" frameborder="0" style="display:none"></iframe>
</noscript>
<!-- End of DoubleClick Floodlight Tag: Please do not remove -->
<?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/accessories.html"){ ?> <!--
Start of DoubleClick Floodlight Tag: Please do not remove
Activity name of this tag: 06. Product - Accessories
URL of the web page where the tag is expected to be placed: https://www.willowandhall.co.uk/accessories.html
This tag must be placed between the <body> and </body> tags, as close as possible to the opening tag.
Creation Date: 06/02/2016
-->
<script type="text/javascript">
var axel = Math.random() + "";
var a = axel * 10000000000000;
document.write('<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=06pro0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>');
</script>
<noscript>
<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=06pro0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?" width="1" height="1" frameborder="0" style="display:none"></iframe>
</noscript>
<!-- End of DoubleClick Floodlight Tag: Please do not remove -->
<?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/clearance.html"){ ?> <!--
Start of DoubleClick Floodlight Tag: Please do not remove
Activity name of this tag: 07. Product - Clearance
URL of the web page where the tag is expected to be placed: https://www.willowandhall.co.uk/clearance.html
This tag must be placed between the <body> and </body> tags, as close as possible to the opening tag.
Creation Date: 06/02/2016
-->
<script type="text/javascript">
var axel = Math.random() + "";
var a = axel * 10000000000000;
document.write('<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=07pro0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>');
</script>
<noscript>
<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=07pro0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?" width="1" height="1" frameborder="0" style="display:none"></iframe>
</noscript>
<!-- End of DoubleClick Floodlight Tag: Please do not remove -->
<?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/shop-by-range.html"){ ?> <!--
Start of DoubleClick Floodlight Tag: Please do not remove
Activity name of this tag: 08. Shop by Range
URL of the web page where the tag is expected to be placed: https://www.willowandhall.co.uk/shop-by-range.html
This tag must be placed between the <body> and </body> tags, as close as possible to the opening tag.
Creation Date: 06/02/2016
-->
<script type="text/javascript">
var axel = Math.random() + "";
var a = axel * 10000000000000;
document.write('<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=08sho0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>');
</script>
<noscript>
<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=08sho0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?" width="1" height="1" frameborder="0" style="display:none"></iframe>
</noscript>
<!-- End of DoubleClick Floodlight Tag: Please do not remove -->
<?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/free-samples"){ ?> <!--
Start of DoubleClick Floodlight Tag: Please do not remove
Activity name of this tag: 09. Free Samples
URL of the web page where the tag is expected to be placed: https://www.willowandhall.co.uk/free-samples
This tag must be placed between the <body> and </body> tags, as close as possible to the opening tag.
Creation Date: 06/02/2016
-->
<script type="text/javascript">
var axel = Math.random() + "";
var a = axel * 10000000000000;
document.write('<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=09fre0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>');
</script>
<noscript>
<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=09fre0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?" width="1" height="1" frameborder="0" style="display:none"></iframe>
</noscript>
<!-- End of DoubleClick Floodlight Tag: Please do not remove -->
<?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/checkout/cart/"){ ?> <!--
Start of DoubleClick Floodlight Tag: Please do not remove
Activity name of this tag: 10. Basket Page
URL of the web page where the tag is expected to be placed: https://www.willowandhall.co.uk/checkout/cart/
This tag must be placed between the <body> and </body> tags, as close as possible to the opening tag.
Creation Date: 06/02/2016
-->
<script type="text/javascript">
var axel = Math.random() + "";
var a = axel * 10000000000000;
document.write('<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=10bas0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];u6=[No. of Items];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>');
</script>
<noscript>
<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=10bas0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];u6=[No. of Items];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?" width="1" height="1" frameborder="0" style="display:none"></iframe>
</noscript>
<!-- End of DoubleClick Floodlight Tag: Please do not remove -->
<?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/onestepcheckout/"){ ?> <!--
Start of DoubleClick Floodlight Tag: Please do not remove
Activity name of this tag: 11. Checkout Page
URL of the web page where the tag is expected to be placed: https://www.willowandhall.co.uk/onestepcheckout/
This tag must be placed between the <body> and </body> tags, as close as possible to the opening tag.
Creation Date: 06/02/2016
-->
<script type="text/javascript">
var axel = Math.random() + "";
var a = axel * 10000000000000;
document.write('<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=11che0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];u6=[No. of Items];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>');
</script>
<noscript>
<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=11che0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];u6=[No. of Items];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?" width="1" height="1" frameborder="0" style="display:none"></iframe>
</noscript>
<!-- End of DoubleClick Floodlight Tag: Please do not remove -->
<?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/checkout/onepage/success/"){ ?> <!--
Start of DoubleClick Floodlight Tag: Please do not remove
Activity name of this tag: 12. Order Confirmation
URL of the web page where the tag is expected to be placed: https://www.willowandhall.co.uk/ORDER-CONFIRMATION
This tag must be placed between the <body> and </body> tags, as close as possible to the opening tag.
Creation Date: 06/02/2016
-->
<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=order0;cat=12ord0;qty=1;cost=[Revenue];u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];u6=[No. of Items];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=[OrderID]?" width="1" height="1" frameborder="0" style="display:none"></iframe>
<!-- End of DoubleClick Floodlight Tag: Please do not remove -->
<?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/customer/account/create/"){ ?> <!--
Start of DoubleClick Floodlight Tag: Please do not remove
Activity name of this tag: 13. Create Account
URL of the web page where the tag is expected to be placed: https://www.willowandhall.co.uk/customer/account/create/
This tag must be placed between the <body> and </body> tags, as close as possible to the opening tag.
Creation Date: 06/02/2016
-->
<script type="text/javascript">
var axel = Math.random() + "";
var a = axel * 10000000000000;
document.write('<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=13cre0;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>');
</script>
<noscript>
<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=13cre0;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?" width="1" height="1" frameborder="0" style="display:none"></iframe>
</noscript>
<!-- End of DoubleClick Floodlight Tag: Please do not remove -->
<?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/customer/account/login/"){ ?> <!--
Start of DoubleClick Floodlight Tag: Please do not remove
Activity name of this tag: 14. Login Page
URL of the web page where the tag is expected to be placed: https://www.willowandhall.co.uk/customer/account/login/
This tag must be placed between the <body> and </body> tags, as close as possible to the opening tag.
Creation Date: 06/02/2016
-->
<script type="text/javascript">
var axel = Math.random() + "";
var a = axel * 10000000000000;
document.write('<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=14log0;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>');
</script>
<noscript>
<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=14log0;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?" width="1" height="1" frameborder="0" style="display:none"></iframe>
</noscript>
<!-- End of DoubleClick Floodlight Tag: Please do not remove -->
<?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/customer/account/"){ ?> <!--
Start of DoubleClick Floodlight Tag: Please do not remove
Activity name of this tag: 15. My Account Page
URL of the web page where the tag is expected to be placed: https://www.willowandhall.co.uk/MY-ACCOUNT-PAGE
This tag must be placed between the <body> and </body> tags, as close as possible to the opening tag.
Creation Date: 06/02/2016
-->
<script type="text/javascript">
var axel = Math.random() + "";
var a = axel * 10000000000000;
document.write('<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=15mya0;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>');
</script>
<noscript>
<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=15mya0;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?" width="1" height="1" frameborder="0" style="display:none"></iframe>
</noscript>
<!-- End of DoubleClick Floodlight Tag: Please do not remove -->
<?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/wishlist/"){ ?> <!--
Start of DoubleClick Floodlight Tag: Please do not remove
Activity name of this tag: 16. Wishlist
URL of the web page where the tag is expected to be placed: https://www.willowandhall.co.uk/MY-WISHLIST
This tag must be placed between the <body> and </body> tags, as close as possible to the opening tag.
Creation Date: 06/02/2016
-->
<script type="text/javascript">
var axel = Math.random() + "";
var a = axel * 10000000000000;
document.write('<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=16wis0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];u6=[No. of Items];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>');
</script>
<noscript>
<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=16wis0;u2=[Product Range];u3=[Product Page];u4=[Product ID];u5=[Item Price];u6=[No. of Items];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?" width="1" height="1" frameborder="0" style="display:none"></iframe>
</noscript>
<!-- End of DoubleClick Floodlight Tag: Please do not remove -->
<?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/PHONE-ORDER"){ ?> <?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/CALLBACK-CONFIRMATION"){ ?> <?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/CATALOGUE-CONFIRMATION"){ ?> <?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/contact-us"){ ?> <!--
Start of DoubleClick Floodlight Tag: Please do not remove
Activity name of this tag: 20. Contact Us Page
URL of the web page where the tag is expected to be placed: https://www.willowandhall.co.uk/contact-us
This tag must be placed between the <body> and </body> tags, as close as possible to the opening tag.
Creation Date: 06/02/2016
-->
<script type="text/javascript">
var axel = Math.random() + "";
var a = axel * 10000000000000;
document.write('<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=20con0;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>');
</script>
<noscript>
<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=20con0;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?" width="1" height="1" frameborder="0" style="display:none"></iframe>
</noscript>
<!-- End of DoubleClick Floodlight Tag: Please do not remove -->
<?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/showroom"){ ?> <!--
Start of DoubleClick Floodlight Tag: Please do not remove
Activity name of this tag: 21. Showroom Page
URL of the web page where the tag is expected to be placed: https://www.willowandhall.co.uk/showroom
This tag must be placed between the <body> and </body> tags, as close as possible to the opening tag.
Creation Date: 06/02/2016
-->
<script type="text/javascript">
var axel = Math.random() + "";
var a = axel * 10000000000000;
document.write('<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=21sho0;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>');
</script>
<noscript>
<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=21sho0;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?" width="1" height="1" frameborder="0" style="display:none"></iframe>
</noscript>
<!-- End of DoubleClick Floodlight Tag: Please do not remove -->
<?php }
else if($actual_link == "http://newdev.willowandhall.co.uk/catalogsearch/result/?q=cart"){ ?> <!--
	Start of DoubleClick Floodlight Tag: Please do not remove
	Activity name of this tag: 22. Search Page
	URL of the web page where the tag is expected to be placed: https://www.willowandhall.co.uk/SEARCH-RESULTS
	This tag must be placed between the <body> and </body> tags, as close as possible to the opening tag.
	Creation Date: 06/02/2016
	-->
	<script type="text/javascript">
	var axel = Math.random() + "";
	var a = axel * 10000000000000;
	document.write('<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=22sea0;u1=[Search Term];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>');
	</script>
	<noscript>
	<iframe src="https://5688510.fls.doubleclick.net/activityi;src=5688510;type=willo0;cat=22sea0;u1=[Search Term];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?" width="1" height="1" frameborder="0" style="display:none"></iframe>
	</noscript>
	<!-- End of DoubleClick Floodlight Tag: Please do not remove -->
<?php }
else{echo '<script>"Tag no found"</script>';}



?>
