Please check here:

http://www.96down.com/slider-revolution-responsive-wordpress-plugin-download/