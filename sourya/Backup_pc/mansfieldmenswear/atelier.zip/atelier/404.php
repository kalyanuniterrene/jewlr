<?php get_header(); ?>

<div class="container">

	<?php sf_base_layout('404'); ?>
	
</div>

<?php get_footer(); ?>