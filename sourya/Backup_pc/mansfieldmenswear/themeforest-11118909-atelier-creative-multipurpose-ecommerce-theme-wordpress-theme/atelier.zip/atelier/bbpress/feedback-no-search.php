<?php

/**
 * No Search Results Feedback Part
 *
 * @package bbPress
 * @subpackage Atelier
 */

?>

<div class="bbp-template-notice">
	<p><?php _e( 'Oh bother! No search results were found here!', 'bbpress' ); ?></p>
</div>
