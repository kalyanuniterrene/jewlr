<?php

/**
 * No Topics Feedback Part
 *
 * @package bbPress
 * @subpackage Atelier
 */

?>

<div class="bbp-template-notice">
	<p><?php _e( 'Oh bother! No topics were found here!', 'bbpress' ); ?></p>
</div>
