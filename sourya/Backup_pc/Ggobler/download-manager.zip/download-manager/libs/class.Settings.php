<?php


namespace WPDM;

class Settings
{




}