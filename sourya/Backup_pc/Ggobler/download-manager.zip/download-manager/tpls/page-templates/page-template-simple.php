<!-- WPDM Template: Simplified Template -->

<div class="row">

    <div class="col-md-12"><br/>
 
<ul class="list-group">
  <li class="list-group-item">
    <span class="badge">[download_count]</span>
    Download
  </li>
  <li class="list-group-item">
    <span class="badge">[file_size]</span>
    File Size
  </li>
  <li class="list-group-item">
    <span class="badge">[create_date]</span>
    Create Date
  </li>
  <li class="list-group-item">
    [download_link_extended]
  </li>
</ul>>
        </div>


<div class="col-md-12">
[description]



</div>
</div>
