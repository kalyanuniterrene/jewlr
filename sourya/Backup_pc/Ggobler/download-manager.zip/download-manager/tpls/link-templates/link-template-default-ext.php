<!-- WPDM Link Template: Default Template (Extended) -->

<div class="panel panel-default">
    <div class="panel-body">
 
    <div class="media">
        <div class="pull-left">[icon]</div>
        <div class="media-body"><strong class="ptitle">[title]</strong>
            [description]
            <div><strong>[download_link_extended]</strong></div>
        </div>
    </div>
 
 
    </div>
    <div class="panel-footer"><span class="pull-right">[download_count] downloads</span>[file_size]</div>
</div>