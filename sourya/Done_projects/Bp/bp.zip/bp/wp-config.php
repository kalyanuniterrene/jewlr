<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'unitetoh_bp');

/** MySQL database username */
define('DB_USER', 'unitetoh_bp');

/** MySQL database password */
define('DB_PASSWORD', '@tiR9+3~ke;@');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '_g)K2yoL*W^U:>T/S$`!{:L-V0FDg3OAUa,l:,{:XSF92i9Z2Zy~=q4G8Id&BvO%');
define('SECURE_AUTH_KEY',  ']YoN2`$LP0i4E^tOt9M:O)~2YAk+)*+B}>+.IqY #6<(->rA^n*C5-R$Q~zm}O7E');
define('LOGGED_IN_KEY',    'U}qw3&Kd_FeI@anU7{BY$xnwUqF=kqYpfhEjb8,()$9+QlZ_r;ZmT|MX,,7nrWg3');
define('NONCE_KEY',        'J VV`H.lBY5U=!6N`)>Xd#0Z/=O5QJ`6`1i$G&}R7;*yw?Ho(K9w#tPm-:=D5~0+');
define('AUTH_SALT',        'BCq<A46%1YC,-G/eD`xSJG<7i.9;6Im?-*+,)y!^qI7s?)&eMskEWpFKL$N#b2tN');
define('SECURE_AUTH_SALT', 'gvdpydoXwfIWNw4ksyVuCT T8I` O6Y//2e}.mwAj$3k}`i5%aU7SLJIVJIjqMi~');
define('LOGGED_IN_SALT',   'bldtA&7Vc[R4RfL[*xLH[.[!l=a-/z|aIBtfv:W+!C:S2Y)4fa(0]5pqsl#c7,W]');
define('NONCE_SALT',       'v@[N2T:Ul+>JKF)Y4Q_C.9NmFM+] Kke-[e#?E4C4fT(cV[B!yWYn!-dI0@=jcs!');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'bp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
