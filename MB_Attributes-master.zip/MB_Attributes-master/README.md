# MB_Attributes

Simple module to add attributes to Shopping Cart Price Rule/coupon in Magento 1.x.

See full discussion here: magento.stackexchange.com/questions/67949/add-attribute-to-shopping-cart-price-rule-coupon/
